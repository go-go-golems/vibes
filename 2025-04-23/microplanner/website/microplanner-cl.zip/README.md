# Micro-PLANNER Common Lisp Implementation

This is a modern Common Lisp implementation of the historically significant Micro-PLANNER programming language, originally developed at MIT in the late 1960s and early 1970s.

## Contents

- `microplanner.lisp` - Core implementation of Micro-PLANNER
- `package.lisp` - Package definitions
- `system.lisp` - System definition for loading
- `simplified-examples.lisp` - Simple examples demonstrating core functionality
- `examples.lisp` - More complex examples (may require optimization for deep recursion)
- `run-simplified-examples.lisp` - Script to run the simplified examples
- `examples-output.txt` - Output from running the examples
- `docs/` - Documentation including guide and tutorial

## Installation

1. Ensure you have SBCL (Steel Bank Common Lisp) installed
2. Load the system:
   ```
   sbcl --load system.lisp
   ```
3. Run the examples:
   ```
   sbcl --script run-simplified-examples.lisp
   ```

## Features

- Pattern-directed invocation
- Assertions and database management
- Goal-directed execution
- Backtracking
- Theorem proving
- Forward and backward chaining

## Documentation

See the `docs/` directory for comprehensive documentation:
- `guide.md` - Comprehensive guide to Micro-PLANNER
- `tutorial.md` - Step-by-step tutorial

## License

This implementation is provided for educational and research purposes.

## Acknowledgments

Based on the original Micro-PLANNER developed by Gerry Sussman, Eugene Charniak, and Terry Winograd at MIT.
