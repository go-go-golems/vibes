# Logs by Service

| Service | Count |
|---------|-------|
| analytics-service | 200 |
| flow | 50 |
| inventory-service | 200 |
| kafka | 200 |
| notification-service | 200 |
| order-service | 200 |
| payment-service | 200 |
| shipping-service | 200 |
| zookeeper | 200 |


| Level | Count |
|-------|-------|
| INFO | 0 |
| DEBUG | 0 |
| WARN | 0 |
| ERROR | 0 |
| FATAL | 0 |


| Scenario | Status | Logs |
|----------|--------|------|
| scenario1_happy_path_20250425_032005 | Success | 8 |
| scenario1_happy_path_20250425_032036 | Success | 8 |
| scenario2_payment_failure_20250425_032047 | Success | 8 |
| scenario3_inventory_shortage_20250425_032055 | Success | 8 |
| scenario4_shipping_delay_20250425_032104 | Success | 8 |
| scenario5_high_load_20250425_032116 | Success | 8 |
| scenario6_recovery_test_20250425_032124 | Success | 8 |


| Service | Error | Count |
|---------|-------|-------|
