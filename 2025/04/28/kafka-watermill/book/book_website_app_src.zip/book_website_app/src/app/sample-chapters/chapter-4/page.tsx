import Navbar from "../../../components/Navbar";
import Footer from "../../../components/Footer";
import Link from "next/link";

export default function Chapter4Sample() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <div className="bg-white py-12">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-10">
              <Link href="/sample-chapters" className="text-red-600 hover:text-red-800">
                ← Back to Sample Chapters
              </Link>
            </div>
            
            <h1 className="text-3xl font-extrabold text-gray-900 mb-6">
              Chapter 4: Kafka From 10,000 ft (Enhanced)
            </h1>
            
            <div className="prose prose-red prose-lg max-w-none">
              <p>
                Apache Kafka has emerged as one of the most powerful and versatile distributed streaming platforms, serving as the backbone for event-driven architectures across industries. Before diving into the implementation details of our polyglot system, it's essential to understand Kafka's core concepts and architecture. This chapter provides a high-level overview of Kafka, explaining its key components and how they work together to enable scalable, resilient event streaming, drawing insights from foundational texts like "Kafka in Action" by Scott, Gamov, and Klein.
              </p>
              
              <h2>The Evolution of Kafka</h2>
              
              <p>
                Apache Kafka was originally developed at LinkedIn around 2010 to address the growing need for real-time data processing at scale. Traditional message queues and enterprise service buses couldn't handle LinkedIn's requirements for high throughput, fault tolerance, and horizontal scalability. The team, led by Jay Kreps (who later founded Confluent), designed Kafka as a distributed commit log that could serve as a central data pipeline for the entire organization.
              </p>
              
              <p>
                Since its inception, Kafka has evolved from a messaging system to a comprehensive event streaming platform. It now encompasses not only the core broker functionality but also Kafka Connect (for integrating with external systems), Kafka Streams (for stream processing), and ksqlDB (for SQL-based stream processing).
              </p>
              
              <h2>Core Components of Kafka</h2>
              
              <p>
                At its heart, Kafka is a distributed, partitioned, replicated commit log service. Let's break down the key components that make up a Kafka deployment:
              </p>
              
              <h3>Topics: The Fundamental Organizing Unit</h3>
              <p>
                A <strong>topic</strong> is a named, append-only log to which data can be published. Topics serve as the primary categorization mechanism in Kafka, typically representing a particular stream of data or class of events (e.g., <code>order.events</code>, <code>user.activity</code>).
              </p>
              
              <h3>Partitions: Enabling Parallelism and Scalability</h3>
              <p>
                Each topic is divided into one or more <strong>partitions</strong>, which are the actual append-only logs that store the data. Partitions serve several critical purposes:
              </p>
              <ul>
                <li><strong>Horizontal Scaling</strong>: By splitting a topic across multiple partitions, Kafka can distribute the load across multiple brokers.</li>
                <li><strong>Parallelism</strong>: Multiple consumers can process different partitions of the same topic simultaneously.</li>
                <li><strong>Ordering Guarantees</strong>: Within a single partition, Kafka guarantees that messages are stored and delivered in the exact order they were received.</li>
              </ul>
              <p>
                Each message within a partition is assigned a sequential ID called an <strong>offset</strong>, which uniquely identifies its position in the partition.
              </p>
              
              <pre className="bg-gray-100 p-4 rounded-md overflow-auto">
                ┌─ Topic: order.created ──────────────────────────────────────────┐
                │                                                                 │
                │  ┌─ Partition 0 ─┐  ┌─ Partition 1 ─┐  ┌─ Partition 2 ─┐       │
                │  │ Offset: 0     │  │ Offset: 0     │  │ Offset: 0     │       │
                │  │ Offset: 1     │  │ Offset: 1     │  │ Offset: 1     │       │
                │  │ Offset: 2     │  │ Offset: 2     │  │ Offset: 2     │       │
                │  │ Offset: 3     │  │ Offset: 3     │  │ Offset: 3     │       │
                │  │ ...           │  │ ...           │  │ ...           │       │
                │  └───────────────┘  └───────────────┘  └───────────────┘       │
                │                                                                 │
                └─────────────────────────────────────────────────────────────────┘
              </pre>
              
              <h3>Brokers: The Servers That Power Kafka</h3>
              <p>
                A Kafka cluster consists of one or more <strong>brokers</strong>—servers that store the partitions and serve client requests. Each broker hosts a subset of the partitions across all topics, distributing the storage and processing load.
              </p>
              
              <div className="bg-red-50 border-l-4 border-red-500 p-4 my-6">
                <p className="text-red-700">
                  <strong>Want to read more?</strong> This is just a sample from Chapter 4. The full chapter continues with:
                </p>
                <ul className="list-disc list-inside text-red-700 mt-2">
                  <li>Replication: Ensuring Fault Tolerance</li>
                  <li>Producers: Publishing Events to Kafka</li>
                  <li>Consumers & Consumer Groups: Reading Events from Kafka</li>
                  <li>ZooKeeper/KRaft: Cluster Coordination</li>
                  <li>The Big Picture: How Components Interact</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
