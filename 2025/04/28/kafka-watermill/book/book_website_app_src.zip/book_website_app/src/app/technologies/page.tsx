import Navbar from "../../components/Navbar";
import Footer from "../../components/Footer";

export default function Technologies() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <div className="bg-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:text-center">
              <h2 className="text-base text-red-600 font-semibold tracking-wide uppercase">Technologies</h2>
              <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
                The Polyglot Stack
              </p>
              <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
                Explore the specific technologies and libraries used in the book's reference implementation.
              </p>
            </div>

            <div className="mt-16">
              <div className="space-y-16">
                {/* Apache Kafka */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Apache Kafka</h3>
                    <div className="mt-4 prose prose-red text-gray-500">
                      <p>
                        The central nervous system of our event-driven architecture. Kafka provides a scalable, fault-tolerant, and durable platform for managing event streams.
                      </p>
                      <ul>
                        <li><strong>Topics & Partitions:</strong> Understanding how data is organized and scaled.</li>
                        <li><strong>Producers & Consumers:</strong> Implementing clients to publish and subscribe to events.</li>
                        <li><strong>Delivery Guarantees:</strong> Exploring at-most-once, at-least-once, and exactly-once semantics.</li>
                        <li><strong>Configuration:</strong> Key settings for performance and reliability.</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Go Implementation */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Go (Golang)</h3>
                    <div className="mt-4 prose prose-red text-gray-500">
                      <p>
                        Used for building efficient, high-performance services. The book utilizes the <strong>Watermill</strong> library for Kafka integration.
                      </p>
                      <ul>
                        <li><strong>Watermill Library:</strong> A versatile Go library for building event-driven applications.</li>
                        <li><strong>Publishers & Subscribers:</strong> Implementing Kafka producers and consumers with Watermill.</li>
                        <li><strong>Middleware:</strong> Using Watermill middleware for common tasks like error handling and retries.</li>
                        <li><strong>Event Sourcing Example:</strong> Demonstrating event sourcing patterns in Go.</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Kotlin Implementation */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Kotlin</h3>
                    <div className="mt-4 prose prose-red text-gray-500">
                      <p>
                        Leveraging the power of the JVM with modern language features. The book uses <strong>Spring Kafka</strong> for seamless integration within the Spring Boot ecosystem.
                      </p>
                      <ul>
                        <li><strong>Spring Kafka:</strong> High-level abstractions for Kafka producers and consumers.</li>
                        <li><strong>@KafkaListener:</strong> Simple annotation-based consumption.</li>
                        <li><strong>KafkaTemplate:</strong> Convenient way to produce messages.</li>
                        <li><strong>Saga Implementation:</strong> Building distributed transaction coordination with Kotlin.</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Ruby Implementation */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Ruby</h3>
                    <div className="mt-4 prose prose-red text-gray-500">
                      <p>
                        A dynamic and expressive language, used in the reference implementation for data processing and analytics tasks. Integration is achieved using the <strong>ruby-kafka</strong> gem.
                      </p>
                      <ul>
                        <li><strong>ruby-kafka Gem:</strong> The standard Kafka client library for Ruby.</li>
                        <li><strong>Producing Messages:</strong> Sending events to Kafka topics.</li>
                        <li><strong>Consuming Messages:</strong> Processing event streams with consumer groups.</li>
                        <li><strong>Analytics Service Example:</strong> Demonstrating a practical use case for Ruby in the system.</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Protocol Buffers */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Protocol Buffers (Protobuf)</h3>
                    <div className="mt-4 prose prose-red text-gray-500">
                      <p>
                        Used for defining language-neutral, platform-neutral, extensible mechanisms for serializing structured data – essential for managing contracts between polyglot services.
                      </p>
                      <ul>
                        <li><strong>Schema Definition:</strong> Defining event structures in `.proto` files.</li>
                        <li><strong>Code Generation:</strong> Generating data classes for Go, Kotlin, and Ruby.</li>
                        <li><strong>Schema Evolution:</strong> Strategies for managing changes to event formats over time.</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
