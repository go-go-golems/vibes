import Navbar from "../../../components/Navbar";
import Footer from "../../../components/Footer";
import Link from "next/link";

export default function Chapter7Sample() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <div className="bg-white py-12">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-10">
              <Link href="/sample-chapters" className="text-red-600 hover:text-red-800">
                ← Back to Sample Chapters
              </Link>
            </div>
            
            <h1 className="text-3xl font-extrabold text-gray-900 mb-6">
              Chapter 7: Go: Efficient Simplicity with Watermill
            </h1>
            
            <div className="prose prose-red prose-lg max-w-none">
              <p>
                Welcome to Part III of our journey, where we transition from the foundational principles of Kafka and event-driven architecture to the practical implementation details within our polyglot system. In this chapter, we focus on Go (Golang), a language renowned for its simplicity, efficiency, and strong concurrency support. We explore how Go, combined with the idiomatic Watermill library, provides a powerful and pragmatic approach to building event-driven services that interact with Kafka.
              </p>
              
              <p>
                As discussed in Chapter 3, Go is often chosen for microservices due to its performance characteristics, low resource consumption, and ease of deployment. Its straightforward syntax and built-in concurrency primitives (goroutines and channels) make it well-suited for handling high-throughput event streams and network-intensive tasks. However, interacting directly with Kafka clients can still involve significant boilerplate code for message handling, retries, and error management. This is where Watermill comes in.
              </p>
              
              <h2>Introducing Watermill: An Idiomatic Go Library for Event-Driven Apps</h2>
              
              <p>
                Watermill is a Go library designed to simplify the development of event-driven applications. It provides a set of abstractions and components that handle the common challenges of working with message brokers like Kafka, RabbitMQ, or Google Cloud Pub/Sub. Watermill aims to be idiomatic Go, leveraging interfaces and composition to provide flexibility while reducing boilerplate.
              </p>
              
              <p>
                Key features of Watermill relevant to our Kafka implementation include:
              </p>
              
              <ul>
                <li><strong>Publisher/Subscriber Abstractions</strong>: Provides unified interfaces for publishing and subscribing to messages, regardless of the underlying broker.</li>
                <li><strong>Router</strong>: A powerful component for defining message handlers, middleware, and processing pipelines.</li>
                <li><strong>Middleware</strong>: Offers built-in middleware for common tasks like retries, throttling, correlation, error handling, and poison queue management.</li>
                <li><strong>Pluggable Architecture</strong>: Supports various message brokers through specific implementations (Pub/Subs).</li>
                <li><strong>Structured Logging</strong>: Integrates well with standard Go logging practices.</li>
              </ul>
              
              <p>
                By using Watermill, we can focus more on our application logic and less on the low-level details of Kafka client interaction.
              </p>
              
              <h2>Setting Up Watermill with Kafka in Go</h2>
              
              <p>
                Let's examine how we configure Watermill to interact with Kafka in our Go services, drawing from the reference implementation.
              </p>
              
              <h3>Dependencies</h3>
              
              <p>
                First, we need to include the necessary Watermill packages in our <code>go.mod</code> file:
              </p>
              
              <pre className="bg-gray-100 p-4 rounded-md overflow-auto">
{`// go.mod (simplified)
require (
    github.com/ThreeDotsLabs/watermill v1.3.5
    github.com/ThreeDotsLabs/watermill-kafka/v2 v2.5.0
    // ... other dependencies
)
`}
              </pre>
              
              <p>
                We specifically need <code>watermill</code> for the core library and <code>watermill-kafka/v2</code> for the Kafka-specific Pub/Sub implementation.
              </p>
              
              <h3>Creating a Kafka Publisher</h3>
              
              <p>
                To publish messages to Kafka, we create a Watermill <code>Publisher</code>. The <code>kafka.NewPublisher</code> function takes a configuration and a marshaler (for serializing messages).
              </p>
              
              <div className="bg-red-50 border-l-4 border-red-500 p-4 my-6">
                <p className="text-red-700">
                  <strong>Want to read more?</strong> This is just a sample from Chapter 7. The full chapter continues with:
                </p>
                <ul className="list-disc list-inside text-red-700 mt-2">
                  <li>Complete code examples for setting up Kafka publishers and subscribers</li>
                  <li>Implementing message handlers with Watermill's Router</li>
                  <li>Error handling and retry strategies</li>
                  <li>Practical patterns for event processing in Go</li>
                  <li>Performance considerations and optimizations</li>
                  <li>Testing strategies for Kafka-based Go services</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
