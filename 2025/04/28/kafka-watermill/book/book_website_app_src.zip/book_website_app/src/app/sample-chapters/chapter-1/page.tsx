import Navbar from "../../../components/Navbar";
import Footer from "../../../components/Footer";
import Link from "next/link";

export default function Chapter1Sample() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <div className="bg-white py-12">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-10">
              <Link href="/sample-chapters" className="text-red-600 hover:text-red-800">
                ← Back to Sample Chapters
              </Link>
            </div>
            
            <h1 className="text-3xl font-extrabold text-gray-900 mb-6">
              Chapter 1: The Log-centric World-view
            </h1>
            
            <div className="prose prose-red prose-lg max-w-none">
              <p>
                In the realm of distributed systems, few abstractions have proven as powerful and transformative as the humble log. Despite its simplicity—or perhaps because of it—the log has emerged as a foundational concept that underpins many of today's most scalable and resilient systems. This chapter explores how adopting a log-centric perspective fundamentally changes how we design, build, and reason about distributed applications, particularly when using Apache Kafka.
              </p>
              
              <h2>Beyond Simple Logging: The Distributed Log</h2>
              
              <p>
                When most developers hear the term "log," they immediately think of application logs—those streams of text messages that help debug issues or trace program execution. While useful, these text-based logs represent only a narrow application of a much more powerful concept.
              </p>
              
              <p>
                A <strong>distributed log</strong> is not merely a queue with the ability to seek backward. It represents something far more profound: it is the <strong>memory</strong> of your system. In a log-centric architecture, the log becomes the authoritative record of everything that has happened within your system—the single source of truth from which all other state can be derived.
              </p>
              
              <p>
                At its core, a log is an append-only, totally-ordered sequence of records ordered by time. Each entry is assigned a unique, sequential identifier (often called an offset or sequence number) that establishes its position in the log. This structure is deceptively simple yet incredibly powerful:
              </p>
              
              <pre className="bg-gray-100 p-4 rounded-md overflow-auto">
                [0] Order #1234 created for customer C001
                [1] Payment of $59.99 received for order #1234
                [2] Inventory item SKU-789 reserved for order #1234
                [3] Shipping label created for order #1234
                [4] Order #1234 marked as shipped
              </pre>
              
              <p>
                In this example, each log entry represents an event that occurred in the system. The numbers in brackets represent the log offsets—immutable positions that define the strict ordering of events. This ordering creates a notion of "time" that is decoupled from physical clocks, providing a consistent view of causality across distributed components.
              </p>
              
              <h2>The Inversion of Data Flow</h2>
              
              <p>
                Traditional systems often rely on mutable databases as their source of truth. Applications query these databases to retrieve the current state, modify that state, and write it back. This approach, while familiar, creates numerous challenges in distributed environments: contention, locking, consistency issues across services, and difficulties in tracking how state evolved over time.
              </p>
              
              <p>
                The log-centric approach inverts this model. Instead of treating the current state as primary and changes as transient operations, it treats the <strong>changes themselves</strong> as the primary record. Everything that happens—an order submission, an inventory check, a payment rejection—is persisted as an <strong>immutable, ordered event</strong> in the log. The current state becomes a derived artifact, a point-in-time projection created by processing the log from the beginning (or from a known checkpoint) up to the present.
              </p>
              
              <div className="bg-red-50 border-l-4 border-red-500 p-4 my-6">
                <p className="text-red-700">
                  <strong>Want to read more?</strong> This is just a sample from Chapter 1. The full chapter continues with:
                </p>
                <ul className="list-disc list-inside text-red-700 mt-2">
                  <li>Rebuilding State is Cheap; Snapshots are an Optimization</li>
                  <li>Debugging Becomes Historical; Time-Travel is Possible</li>
                  <li>Integration Boundaries Shift from Endpoints to Messages</li>
                  <li>Why Kafka Embodies the Log Abstraction</li>
                  <li>The Log in Practice: A Real-World Example</li>
                  <li>Beyond Individual Services: System-Wide Benefits</li>
                  <li>Challenges and Considerations</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
