import Navbar from "../../components/Navbar";
import Footer from "../../components/Footer";

export default function About() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <div className="bg-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:text-center">
              <h2 className="text-base text-red-600 font-semibold tracking-wide uppercase">About the Book</h2>
              <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
                Polyglot Event-Driven Systems with Kafka
              </p>
              <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
                A practical journey through building resilient, scalable systems with Apache Kafka
              </p>
            </div>

            <div className="mt-10">
              <div className="prose prose-red prose-lg text-gray-500 mx-auto">
                <p>
                  This book was born from the crucible of a real-world transformation. It chronicles a practical journey: migrating an established, primarily Go-based system onto the powerful <strong>Apache Kafka</strong> platform. This wasn't just a simple lift-and-shift operation. It involved strategically introducing <strong>Kotlin</strong> to leverage the strengths of the JVM for specific workloads while ensuring the continued operation and integration of a vital existing <strong>Ruby</strong> service responsible for data science tasks.
                </p>
                
                <p>
                  The goal was not merely to replace one technology with another but to fundamentally reshape the system's communication patterns, moving away from brittle, tightly-coupled REST calls and overloaded message queues towards a more resilient, scalable, and observable event-driven paradigm.
                </p>

                <h3>Who Is This Book For?</h3>
                <p>This book is primarily aimed at practitioners who are grappling with the complexities of modern distributed systems, particularly those considering or undergoing a transition to Kafka and event-driven architectures. Specifically, it will be most valuable for:</p>
                
                <ul>
                  <li><strong>Senior Engineers and Tech Leads:</strong> Individuals responsible for guiding teams through the technical challenges of adopting Kafka, designing event-driven flows, and managing polyglot environments.</li>
                  <li><strong>Developers:</strong> Engineers comfortable working in Go, Ruby, or JVM languages (like Kotlin or Java) who want to understand how different runtimes can effectively integrate and communicate using Kafka as a common backbone.</li>
                  <li><strong>Architects:</strong> Professionals looking for battle-tested, production-oriented patterns and strategies for building scalable, resilient event-driven systems.</li>
                </ul>

                <h3>How This Book Is Organized</h3>
                <p>To guide you through this journey, the book is structured into five main parts, followed by appendices:</p>
                
                <ul>
                  <li><strong>Part I — Principles:</strong> Lays the conceptual foundation. We explore the transformative power of log-centric thinking, the critical trade-offs involved in achieving loose coupling through eventual consistency, and the reasons why embracing polyglot services is often not just beneficial but necessary in modern systems.</li>
                  <li><strong>Part II — Kafka Essentials:</strong> Dives into the core mechanics of Apache Kafka. We cover topics, partitions, brokers, consumer groups, the practical implications of different delivery semantics, and demystify the often-misunderstood concept of exactly-once processing.</li>
                  <li><strong>Part III — The Polyglot System:</strong> Walks through the practical implementation details of integrating different languages with Kafka. We examine specific libraries and approaches for Go (using Watermill), Kotlin (using Spring Kafka), and Ruby (using ruby-kafka), drawing directly from the reference codebase.</li>
                  <li><strong>Part IV — Event-Driven Patterns:</strong> Explores key architectural patterns that are essential for building robust event-driven systems. This includes managing data contracts with schemas (using Protocol Buffers), implementing reliable workflows with Sagas, leveraging Event Sourcing for immutable history, and applying Command Query Responsibility Segregation (CQRS) effectively.</li>
                  <li><strong>Part V — Operations:</strong> Addresses the crucial aspects of running and maintaining an event-driven system in production. We cover observability strategies, comprehensive testing approaches, deployment considerations, and strategies for scaling and evolving the system over time.</li>
                </ul>

                <h3>The Reference Implementation</h3>
                <p>
                  Throughout this book, every code listing, configuration snippet, and command is derived from a fully functional, integration-tested reference implementation. This codebase embodies the principles and patterns discussed, providing a concrete example of the polyglot system built around Kafka.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
