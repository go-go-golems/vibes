import Navbar from "../../components/Navbar";
import Footer from "../../components/Footer";

export default function KeyConcepts() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <div className="bg-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:text-center">
              <h2 className="text-base text-red-600 font-semibold tracking-wide uppercase">Key Concepts</h2>
              <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
                Core Ideas Behind Event-Driven Systems
              </p>
              <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
                Understand the fundamental concepts that power modern event-driven architectures
              </p>
            </div>

            <div className="mt-16">
              <div className="space-y-16">
                {/* Log-centric Architecture */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Log-centric Architecture</h3>
                    <div className="mt-4 prose prose-red text-gray-500">
                      <p>
                        A <strong>distributed log</strong> is not merely a queue with the ability to seek backward. It represents something far more profound: it is the <strong>memory</strong> of your system. In a log-centric architecture, the log becomes the authoritative record of everything that has happened within your system—the single source of truth from which all other state can be derived.
                      </p>
                      <p>
                        At its core, a log is an append-only, totally-ordered sequence of records ordered by time. Each entry is assigned a unique, sequential identifier (often called an offset or sequence number) that establishes its position in the log.
                      </p>
                      <p>
                        The log-centric approach inverts the traditional data flow model. Instead of treating the current state as primary and changes as transient operations, it treats the <strong>changes themselves</strong> as the primary record. Everything that happens is persisted as an <strong>immutable, ordered event</strong> in the log.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Loose Coupling & Eventual Consistency */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Loose Coupling & Eventual Consistency</h3>
                    <div className="mt-4 prose prose-red text-gray-500">
                      <p>
                        Event-driven systems embrace <strong>loose coupling</strong> between services. Instead of direct, synchronous API calls, services communicate through events published to and consumed from the log. This decoupling allows services to evolve independently, as long as they maintain compatibility with the event formats they consume and produce.
                      </p>
                      <p>
                        This approach typically embraces <strong>eventual consistency</strong> rather than immediate consistency. While this requires careful design of business processes and user experiences to account for potential delays in state propagation, it enables greater scalability and resilience.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Polyglot Services */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Polyglot Services</h3>
                    <div className="mt-4 prose prose-red text-gray-500">
                      <p>
                        Modern systems often benefit from a <strong>polyglot approach</strong>, using different programming languages for different services based on their specific requirements and team expertise. Kafka serves as a common backbone that enables these diverse services to communicate effectively.
                      </p>
                      <p>
                        This book explores implementations in three languages:
                      </p>
                      <ul>
                        <li><strong>Go</strong>: Efficient, simple, and excellent for high-throughput services</li>
                        <li><strong>Kotlin</strong>: Leveraging the JVM ecosystem with modern language features</li>
                        <li><strong>Ruby</strong>: Dynamic and expressive, ideal for data processing and analytics</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Event-Driven Patterns */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Event-Driven Patterns</h3>
                    <div className="mt-4 prose prose-red text-gray-500">
                      <p>
                        The book explores several key patterns for building robust event-driven systems:
                      </p>
                      <ul>
                        <li><strong>Sagas</strong>: Coordinating distributed transactions across multiple services</li>
                        <li><strong>Event Sourcing</strong>: Using the log of events as the system of record</li>
                        <li><strong>CQRS</strong> (Command Query Responsibility Segregation): Separating read and write operations for better scalability</li>
                        <li><strong>Contracts & Schemas</strong>: Managing data formats across services with Protocol Buffers</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
