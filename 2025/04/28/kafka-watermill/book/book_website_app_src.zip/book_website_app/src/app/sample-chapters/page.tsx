import Navbar from "../../components/Navbar";
import Footer from "../../components/Footer";
import Link from "next/link";

export default function SampleChapters() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <div className="bg-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:text-center">
              <h2 className="text-base text-red-600 font-semibold tracking-wide uppercase">Sample Chapters</h2>
              <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
                Get a Taste of the Book
              </p>
              <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
                Explore excerpts from key chapters to understand the book's style and depth.
              </p>
            </div>

            <div className="mt-10">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {/* Chapter 1 Sample */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-xl font-bold text-gray-900">Chapter 1: The Log-centric World-view</h3>
                    <p className="mt-3 text-base text-gray-500">
                      Understand the foundational concept of the distributed log and how it transforms system design.
                    </p>
                    <div className="mt-4">
                      <Link href="/sample-chapters/chapter-1" className="text-base font-medium text-red-600 hover:text-red-500">
                        Read Sample →
                      </Link>
                    </div>
                  </div>
                </div>

                {/* Chapter 4 Sample */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-xl font-bold text-gray-900">Chapter 4: Kafka From 10,000 ft</h3>
                    <p className="mt-3 text-base text-gray-500">
                      Get a high-level overview of Kafka's architecture, core components, and how they interact.
                    </p>
                    <div className="mt-4">
                      <Link href="/sample-chapters/chapter-4" className="text-base font-medium text-red-600 hover:text-red-500">
                        Read Sample →
                      </Link>
                    </div>
                  </div>
                </div>

                {/* Chapter 7 Sample */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-xl font-bold text-gray-900">Chapter 7: Go with Watermill</h3>
                    <p className="mt-3 text-base text-gray-500">
                      Explore building Kafka services in Go using the idiomatic Watermill library.
                    </p>
                    <div className="mt-4">
                      <Link href="/sample-chapters/chapter-7" className="text-base font-medium text-red-600 hover:text-red-500">
                        Read Sample →
                      </Link>
                    </div>
                  </div>
                </div>

                {/* Add more sample chapter links here as needed */}

              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
