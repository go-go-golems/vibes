import Navbar from "../../components/Navbar";
import Footer from "../../components/Footer";

export default function Resources() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <div className="bg-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:text-center">
              <h2 className="text-base text-red-600 font-semibold tracking-wide uppercase">Resources</h2>
              <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
                Further Reading & Tools
              </p>
              <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
                Explore additional resources, tools, and communities related to Kafka and event-driven systems.
              </p>
            </div>

            <div className="mt-16">
              <div className="space-y-12">
                {/* Official Kafka Resources */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Official Kafka Resources</h3>
                    <ul className="mt-4 list-disc list-inside prose prose-red text-gray-500">
                      <li><a href="https://kafka.apache.org/documentation/" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">Apache Kafka Documentation</a></li>
                      <li><a href="https://cwiki.apache.org/confluence/display/KAFKA/Index" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">Apache Kafka Wiki</a></li>
                      <li><a href="https://github.com/apache/kafka" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">Kafka Source Code (GitHub)</a></li>
                    </ul>
                  </div>
                </div>

                {/* Reference Books */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Reference Books Mentioned</h3>
                    <ul className="mt-4 list-disc list-inside prose prose-red text-gray-500">
                      <li>Kafka in Action (Scott, Gamov, Klein)</li>
                      <li>Kafka Streams in Action, 2nd Edition (Bejeck)</li>
                      <li>Learning Domain-Driven Design (Khononov)</li>
                      {/* Add links if available */}
                    </ul>
                  </div>
                </div>

                {/* Key Articles & Blogs */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Key Articles & Blogs</h3>
                    <ul className="mt-4 list-disc list-inside prose prose-red text-gray-500">
                      <li><a href="https://engineering.linkedin.com/distributed-systems/log-what-every-software-engineer-should-know-about-real-time-datas-unifying" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">The Log: What every software engineer should know... (LinkedIn Engineering)</a></li>
                      <li><a href="https://developer.confluent.io/" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">Confluent Developer</a></li>
                      <li><a href="https://www.confluent.io/blog/" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">Confluent Blog</a></li>
                      {/* Add more relevant articles found during research */}
                    </ul>
                  </div>
                </div>
                
                {/* Tools & Libraries */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Tools & Libraries</h3>
                    <ul className="mt-4 list-disc list-inside prose prose-red text-gray-500">
                      <li><a href="https://watermill.io/" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">Watermill (Go)</a></li>
                      <li><a href="https://spring.io/projects/spring-kafka" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">Spring Kafka (Kotlin/Java)</a></li>
                      <li><a href="https://github.com/zendesk/ruby-kafka" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">ruby-kafka (Ruby)</a></li>
                      <li><a href="https://protobuf.dev/" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">Protocol Buffers</a></li>
                      <li><a href="https://www.confluent.io/product/confluent-platform/" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">Confluent Platform</a></li>
                      {/* Add more relevant tools */}
                    </ul>
                  </div>
                </div>

                {/* Community */}
                <div className="bg-gray-50 overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-2xl font-bold text-gray-900">Community</h3>
                    <ul className="mt-4 list-disc list-inside prose prose-red text-gray-500">
                      <li><a href="https://kafka.apache.org/contact" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">Kafka Mailing Lists</a></li>
                      <li><a href="https://community.confluent.io/" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">Confluent Community Slack</a></li>
                      <li><a href="https://stackoverflow.com/questions/tagged/apache-kafka" target="_blank" rel="noopener noreferrer" className="text-red-600 hover:text-red-800">Stack Overflow [apache-kafka]</a></li>
                      {/* Add more community links */}
                    </ul>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
