// Package goagent provides a framework for building LLM-powered agents in Go.
package goagent

// Version is the current version of the framework
const Version = "0.1.0"
